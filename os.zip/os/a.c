
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include <sys/wait.h>



void main(int argc, char* argv[])
{

	//const char* arr[]={"./b.out", "1", "3", "5", "7", "8", "9", NULL};
	
	char* arr[argc];
	
	for(int i=1; i<argc; i++)
	{
		arr[i-1]=argv[i];
	}
	
	/*
	printf("\nPrinting string");
	for(int i=0; i<argc-1; i++)
	{
		printf("%s ", arr[i]);
	}
	*/
	
	//Sorting array
	char* temp[argc];
	for(int i=0; i<argc-2; i++)
	{
		for(int j=1; j<argc-2-i; j++)
		{
			if(atoi(arr[j])>atoi(arr[j+1]))
			{
				temp[j]=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp[j];
			}	
		}
	}
	
	arr[argc-1]=NULL;
	
	
	/*
	printf("\nPrinting sorted string");
	for(int j=0; j<argc-1; j++)
	{
		printf("%s ", arr[j]);
	}
	*/
	
	
	pid_t pid;
	
	pid=fork();
	
	if(pid == 0)
	{
		printf("\nProcess id is: %d", getpid());
		printf("\nParent Process id is: %d \n", getppid());
		
		for(int x=1; x<argc-1; x++)
		{
			printf("%s ",arr[x]);
		}
		
		printf("\n");
		
		execv(arr[0],arr);
	}
	else
	{
		pid = wait(NULL);
		
		printf("\nProcess id is: %d", getpid());
	}


}



