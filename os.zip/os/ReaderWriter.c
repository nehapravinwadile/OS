#include <pthread.h>
#include <stdio.h>
#include <semaphore.h>

sem_t r, w;
int reader_count = 0;

void *reader(void *arg) {
    sem_wait(&r); // Give permission to the reader for reading
    reader_count++; // Increase reader count

    if (reader_count == 1) {
        sem_wait(&w); // If any reader is reading, ask writer to wait
    }

    sem_post(&r); // After reading is done, take back permission

    printf("Reader is Reading!\n");
    printf("Thread ID:%ld\n", pthread_self());

    sem_wait(&r);
    reader_count--;

    if (reader_count == 0) {
        sem_post(&w); // When no reader is reading, allow the writer
    }

    sem_post(&r); // Allow other readers to read
}

void *writer(void *arg) {
    sem_wait(&w);
    printf("Writer is Writing\n");
    printf("Thread ID:%ld\n", pthread_self());
    sem_post(&w);
}

int main() {
    pthread_t rtid[3];
    pthread_t wtid[3];

    sem_init(&w, 0, 1);
    sem_init(&r, 0, 1);

    for (int i = 0; i < 3; i++) {
        pthread_create(&wtid[i], NULL, writer, NULL);
        pthread_create(&rtid[i], NULL, reader, NULL);
    }

    for (int i = 0; i < 3; i++) {
        pthread_join(wtid[i], NULL);
        pthread_join(rtid[i], NULL);
    }

    sem_destroy(&w);
    sem_destroy(&r);
    return 0;
}

