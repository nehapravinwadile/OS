#! /bin/bash

opt=1
while [ "$opt" -lt 6 ]
do

	printf "1. Create Address Book\n2. View Records\n3 .Insert new Record\n4. Delete a Record\n5. Modify a Record\n6. Exit\n\n"
	
	read opt
	case $opt in

1)
		echo "Enter filename : "
		read fileName
		if [ -e $fileName ] ; then
			rm $fileName
		fi
		cont=1
		echo  "NAME\t\tNUMBER\t\t\tADDRESS\n" | cat >> $fileName
		while [ "$cont" -gt 0 ]
		do
			echo "\nEnter Name : "
			read name
			
			echo "Enter Phone Number "
			read number
			
			echo "Enter Address "
			read address
			
			echo "$name\t$number\t\t$address\n" | cat >> $fileName
			
			echo "Enter 0 to Stop, 1 to Enter next :"
			read cont
		done
		;;
2)
		cat $fileName
		;;
	3)
		echo "\nEnter Name : "
		read name
		echo "Enter Phone Number"
		read number
		echo "Enter Address "
		read address
		echo "$name\t$number\t\t$address\n" | cat >> $fileName
		;;
	4)
		echo "Delete record\nEnter Name/Phone Number"
		read pattern
		temp="temp"
		grep -v $pattern $fileName | cat >> $temp 
		rm $fileName
		cat $temp | cat >> $fileName
		rm $temp
		;;
	5)
		echo "Modify record\nEnter Name/Phone Number"
		read pattern
		temp="temp"
		grep -v $pattern $fileName | cat >> $temp
		rm $fileName
		cat $temp | cat >> $fileName
		rm $temp
		echo "Enter Name"
		read name
	        echo "Enter Phone Number"
		read number
		echo "Enter Address of"
		read address
		echo -e "$name\t$number\t\t$address\n" | cat >> $fileName
		;;
	esac
done
