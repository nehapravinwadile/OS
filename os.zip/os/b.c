
#include<stdio.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int binary_Search(int low, int high, int key, int array[], int f ) 
{

	int mid = low + (high - low) / 2;

	if (key == array[mid])
	{
		f=1;
		return mid;
	}
	      	
	if (key<array[mid])
	{
		return binary_Search(low,mid-1,key, array,0);
	}
		
	if (key>array[mid])
	{	
		return binary_Search(mid+1,high,key,array,0);
	}

 
}

void BinarySearch_call(int count, int array[])
{
	int key,index;
	printf("Enter key : ");
	scanf("%d", &key);
	
	index = binary_Search(0,count-1,key,array,0);
	printf("\nPresent at index : %d",index);
}	
	
void main( int argc, char* argv[])
{
	int i,a[argc-1],sum=0;
	for(i=1;i<argc;i++)
	{
		a[i-1] =atoi(argv[i]);   //atoi==ascii to interger conversion.
	}
	//printf("Addition : %d ",sum);
	
	BinarySearch_call(argc, a);
	
}		



